XBMC-Photo-Parade-Screensaver
=============================

A simple alternative to the [maybe?] memory-leaking slideshow screensaver in XBMC

<a rel="license" href="http://creativecommons.org/licenses/by-sa/3.0/deed.en_US"><img alt="Creative Commons License" style="border-width:0" src="http://i.creativecommons.org/l/by-sa/3.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">XBMC Photo Parade Screensaver</span> by <a xmlns:cc="http://creativecommons.org/ns#" href="http://hamaluik.com" property="cc:attributionName" rel="cc:attributionURL">Kenton Hamaluik</a> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/3.0/deed.en_US">Creative Commons Attribution-ShareAlike 3.0 Unported License</a>.
